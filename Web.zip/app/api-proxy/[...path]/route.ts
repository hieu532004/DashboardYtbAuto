export const runtime = 'nodejs'; // bắt buộc Node, không dùng Edge

import { NextRequest } from 'next/server';
const BASE = (process.env.API_UPSTREAM ?? '').replace(/\/$/, '');

async function handler(req: NextRequest, { params }: { params: { path: string[] } }) {
  const url = `${BASE}/${params.path.join('/')}${req.nextUrl.search}`;
  const headers = new Headers(req.headers);
  headers.delete('host');

  const init: RequestInit = {
    method: req.method,
    headers,
    body: ['GET', 'HEAD'].includes(req.method) ? undefined : await req.arrayBuffer(),
    cache: 'no-store',
    redirect: 'follow'
  };

  const res = await fetch(url, init);
  const outHeaders = new Headers(res.headers);
  outHeaders.delete('content-encoding');
  outHeaders.delete('transfer-encoding');
  return new Response(res.body, { status: res.status, headers: outHeaders });
}

export { handler as GET, handler as POST, handler as PUT, handler as PATCH, handler as DELETE, handler as OPTIONS };
